-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2020. Nov 26. 19:48
-- Kiszolgáló verziója: 10.4.11-MariaDB
-- PHP verzió: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `quizgame`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `questions`
--

CREATE TABLE `questions` (
  `question` varchar(250) NOT NULL,
  `correct` varchar(200) NOT NULL,
  `answerone` varchar(200) NOT NULL,
  `answertwo` varchar(200) NOT NULL,
  `answerthree` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- A tábla adatainak kiíratása `questions`
--

INSERT INTO `questions` (`question`, `correct`, `answerone`, `answertwo`, `answerthree`) VALUES
('\'Namaste\' is a traditional greeting in which Asian language?', 'Hindi', 'Mandarin', 'Japanese', 'Korean'),
('How many cervical vertebra does a giraffe have?', '7', '9', '17', '12'),
('How many gas giants are there in our solar system?', '4', '3', '6', '2'),
('How many moons does Jupiter have?', '79', '13', '54', '39'),
('How many sides does an octagon have?', '8', '9', '5', '6'),
('How many strings does a standard bass guitar have?', '4', '6', '5', '7'),
('How many teeth does an adult have?', '32', '36', '28', '24'),
('How much is 3 factorial?', '6', '24', '9 ', '12'),
('What is J.K. Rowling\'s first name?', 'Joanne', 'Jennifer', 'Jane', 'Jean'),
('What is the code of 9 in the binary system?', '1001', '100', '1000', '1011'),
('What is the third number in Pi?', '4', '1', '3', '6'),
('What year was Napoleon Bonaparte exiled?', '1815', '1800', '1798', '1749'),
('When was America discovered?', '1492', '1526', '1494', '1514'),
('When was the Gregorian calendar introduced?', '1582', '1217', '1252', '1547'),
('Where does the drink Metaxa originate from?', 'Greece', 'Turkey', 'Spain', 'France'),
('Which continent has the most countries?', 'Africa', 'Europe', 'Asia', 'America'),
('Which is not a German language?', 'Romanian', 'Afrikaans', 'Scots ', 'Dutch'),
('Which is the world\'s longest river?', 'River Nile', 'Amazon River', 'Mississippi', 'River Thames'),
('Which is the world\'s most populated city?', 'Tokyo', 'Delhi', 'Shanghai', 'Sao Paulo'),
('Which of these is not a suit in a normal deck of cards?', 'Ace', 'Spades', 'Hearts', 'Diamonds');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`question`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
