package sample.model;
//player model osztály
public class PlayerModel extends DataAccessObject {
    //osztály változók
    private String playerName;
    private int playerScore;
    private int playerHp;

    //konstruktor
    public PlayerModel(String name){
        this.playerName = name;
        //az élet és a pontszám alapértelmezetten 3 és 0
        this.playerHp = 3;
        this.playerScore = 0;
    }


    //getterek és setterek az osztályváltozókhoz
    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public int getPlayerScore() {
        return playerScore;
    }

    public void setPlayerScore(int playerScore) {
        this.playerScore = playerScore;
    }

    public int getPlayerHp() {
        return playerHp;
    }

    public void setPlayerHp(int playerHp) {
        this.playerHp = playerHp;
    }
}
