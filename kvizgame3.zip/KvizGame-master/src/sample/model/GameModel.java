package sample.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
//game model osztály
public class GameModel extends DataAccessObject{
    //tömblista amiben tároljuk az adatbázisból lekérdezett a kérdéseket és válaszokat
    private ArrayList<ArrayList<String>> quizSet = new ArrayList<ArrayList<String>>();

    //konstruktor amiben benépesítjük a quizSet tömblistát
    public GameModel() throws SQLException {
        //lekérdezés
        String query = "SELECT question, correct, answerone, answertwo, answerthree FROM questions";
        //result set a lekérdezés eredménye az ősosztály metódusából
        ResultSet rs = super.query(query);

        //kipörgetjük a lekérdezés eredményét
        while(rs.next()){
            //a lekérdezés minden sorát egy tömblistában tároljuk
            ArrayList<String> tempArr = new ArrayList<>();
            //hozzáadjuk ehhez a tömblistához a lekérdezés eredményeit
            tempArr.add(rs.getString("question"));
            tempArr.add(rs.getString("correct"));
            tempArr.add(rs.getString("answerone"));
            tempArr.add(rs.getString("answertwo"));
            tempArr.add(rs.getString("answerthree"));

            //hozzáadjuk a quizSethez ezt a tömblistát
            this.quizSet.add(tempArr);
        }
        //lezárjuk az adatbázis kapcsolatot
        super.close();
    }

    //getter a tömblista értékéhez
    public ArrayList<ArrayList<String>> getQuizSet() {
        return quizSet;
    }
}
