package sample.model;

import java.sql.*;
//data access object
public abstract class DataAccessObject {
    //osztály változók
    private Connection conn;
    private Statement stmt;
    private ResultSet rs;
    private PreparedStatement ps;

    //konstruktor
    //létrehozzuk a kapcsolatot és a statementet
    public DataAccessObject(){
        //adatbázis adatok
        String host = "localhost";
        String db = "quizgame";
        String user = "root";
        String pw = "";

        //try-catch blokk
        try {
            //csatlakozás adatbázishoz
            this.conn = DriverManager.getConnection("jdbc:mysql://"+host+"/"+db, user, pw);
            //statement létrehozása
            this.stmt = this.conn.createStatement();
        }catch (SQLException err){
            //hibaüzenet
            System.out.println("Error!\n" + err.getMessage());
        }
    }

    //lekérdezésekhez metódus
    public ResultSet query(String sql){
        //try-catch blokk
        try {
            //osztály változó beállítása a lekérdezés végeredményére
            this.rs = this.stmt.executeQuery(sql);
        }catch (SQLException err){
            //hibaüzenet
            System.out.println("Error!\n" + err.getMessage());
        }
        //osztályváltozó visszaadása
        return this.rs;
    }

    //insert, update, delete
    public void modify(String sql, String params[]){
        //try-catch blokk
        try {
            //prepared statement
            this.ps = this.conn.prepareStatement(sql);
            for(int i=0;i< params.length;i++){
                //paraméterek hozzáadása a parancshoz
                this.ps.setString(i+1,params[i]);
            }
            //parancs lefuttatása
            this.ps.executeUpdate();
        }catch (SQLException err){
            //hibaüzenet
            System.out.println("Error!\n" + err.getMessage());
        }
    }

    //kapcsolat bezárása
    public void close(){
        //try-catch blokk
        try {
            //ossztály változók bezárása
            if(this.stmt!=null) this.stmt.close();
            if(this.rs!=null) this.rs.close();
            if(this.conn!=null) this.conn.close();
        }catch(Exception err){
            //hibaüzenet
            System.out.println("Adatbázis lezárás sikertelen!");
        }
    }

}
