package sample.controlles;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class FXMLDocumentController implements Initializable {


        @FXML
        public void jatekButtonClicked(ActionEvent event) throws IOException, SQLException {

            Parent gameView = FXMLLoader.load(getClass().getResource("/view/gameView.fxml"));
            Scene gameViewScene = new Scene(gameView, 800, 800);

            Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();

            window.setScene(gameViewScene);
            window.show();

            GameController gc = new GameController();
            gc.nextQuestion();

        }




    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO

    }
}