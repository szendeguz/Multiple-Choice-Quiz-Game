package sample.controlles;

import com.sun.webkit.network.data.Handler;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import sample.model.GameModel;
import javafx.scene.control.Label;
import sample.model.PlayerModel;



//import java.awt.*;
import java.net.URL;
import java.sql.SQLException;
import java.util.*;

import java.util.logging.LogRecord;

//game controller osztály
public class GameController implements Initializable {

    //osztály változók
    private ArrayList<ArrayList<String>> quizSet;
    private PlayerModel player;
    private Random randomNum;
    private String correctAnswer;
    private int playerScore, playerHealth;

    @FXML
    private Label question, score, health;
    public Button answerOne, answerTwo, answerThree, answerFour, btnNext;


    //konstruktor
    public GameController() throws SQLException {
        //lekérjük a modeltől a kétdimenziós tömblistát
        this.quizSet = new GameModel().getQuizSet();
        //új random szám
        this.randomNum = new Random();
        //új játékos objektum
        this.player = new PlayerModel("Viki");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        this.nextQuestion();
    }

    //következő kérdés (és első is) megjelenítése metódus
    public void nextQuestion(){
        this.btnNext.setVisible(false);
        //random szám a tömblista méretével egyenlő
        int random = randomNum.nextInt(this.quizSet.size());

        //új tömblista - ez visszaad egy sort az adatbázis questions táblájából
        ArrayList<String> quiz = new ArrayList<String>();
        //lekéri egy random sort a quizSetből
        quiz = this.quizSet.get(random);

        //itt beállítjuk a kérdést a viewba
        //pl:
        question.setText(quiz.get(0));

        //helyes válasz
        this.correctAnswer = quiz.get(1);

        //kivesszük a kérdést a tömblistából
        quiz.remove(0);

        //megkeverjük a maradék négy elemet a tömblistában, hogy ne a helyes válasz legyen az első helyen
        Collections.shuffle(quiz);

        //itt írjuk ki a válaszokat
        //pl:
        answerOne.setText(quiz.get(0));
        // System.out.println(quiz.get(0));
        answerTwo.setText(quiz.get(1));
        // System.out.println(quiz.get(1));
        answerThree.setText(quiz.get(2));
        // System.out.println(quiz.get(2));
        answerFour.setText(quiz.get(3));
        // System.out.println(quiz.get(3));

        //kivesszük ezt a kérdés szettet a tömblistából
        this.quizSet.remove(random);

        this.setPlayerData();
        this.resetButtons();
    }

    public void setPlayerData(){
        this.playerHealth = this.player.getPlayerHp();
        this.playerScore = this.player.getPlayerScore();

        this.score.setText(Integer.toString(this.playerScore));
        this.health.setText(Integer.toString(this.playerHealth));
    }

    public void checkAnswer(Button button){
        this.btnNext.setVisible(true);
        this.disableButtons();
        
        if(button.getText().equals(this.correctAnswer)){
            int newScore = this.playerScore + 100;
            this.player.setPlayerScore(newScore);

            button.setStyle("-fx-background-color: #03fc0b");

            //this.timer(this.playerHealth);
            this.setPlayerData();
        }else{
            if(this.playerHealth-1>0){
                int newHp = this.playerHealth - 1;
                this.player.setPlayerHp(newHp);

                button.setStyle("-fx-background-color: #fc0303");

                this.setPlayerData();
                //this.timer(newHp);
            }else{
                //itt kell leállítani a játékot
                //megnyitni egy scenet ahol kíirjuk a pontokat, így még nem áll le jelenleg
                System.out.println("YOU DIED!");
            }
        }
    }

    public void resetButtons(){
        this.answerOne.setStyle("-fx-background-color: #28abb9");
        this.answerTwo.setStyle("-fx-background-color: #28abb9");
        this.answerThree.setStyle("-fx-background-color: #28abb9");
        this.answerFour.setStyle("-fx-background-color: #28abb9");

        this.answerOne.setDisable(false);
        this.answerTwo.setDisable(false);
        this.answerThree.setDisable(false);
        this.answerFour.setDisable(false);
    }

    public void disableButtons(){
        this.answerOne.setDisable(true);
        this.answerTwo.setDisable(true);
        this.answerThree.setDisable(true);
        this.answerFour.setDisable(true);
    }

    /*public void timer(int hp){
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                if(hp>0) nextQuestion();
                else System.out.println("YOU DIED");
            }
        },0, 550);
    }*/


    public void btnOneClicked(ActionEvent actionEvent) {
        this.checkAnswer(answerOne);
        //this.nextQuestion();
    }

    public void btnTwoClicked(ActionEvent actionEvent) {
        this.checkAnswer(answerTwo);
    }

    public void btnThreeClicked(ActionEvent actionEvent) {
        this.checkAnswer(answerThree);
    }

    public void btnFourClicked(ActionEvent actionEvent) {
        this.checkAnswer(answerFour);
    }

    public void btnNextClicked(ActionEvent actionEvent) {
        this.nextQuestion();
    }
}